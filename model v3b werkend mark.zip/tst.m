prev_chest_c = 79.8;
avg_chest_c = 70;
range = 19;
relative_c = 0.4956;

phi = 0.77;
phi = 0.2475*pi;
f = 0.21;
dt = 0.5;

t = 0:0.01:3;
plot(t,sin(t*3 + 0.0*pi));

sin(2*pi* f * dt + phi)